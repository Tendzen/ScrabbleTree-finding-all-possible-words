//
//  main.cpp
//  Zapocet_Scrabble
//
//  Created by Paul Ekishev on 25/05/2021.
//

#include "Definitions.h"




int main() {
    
    startProgram();
    return 0;
}

